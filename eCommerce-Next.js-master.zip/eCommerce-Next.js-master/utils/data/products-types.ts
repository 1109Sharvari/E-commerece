export const productsTypes = [
  {
    id: '1',
    name: 'T-Shirts',
    count: '172',
  },
  {
    id: '2',
    name: 'Sweatshirts',
    count: '131',
  },
  {
    id: '3',
    name: 'Tank Tops',
    count: '56',
  },
  {
    id: '4',
    name: 'Dress shirts',
    count: '8',
  },
];

export default productsTypes;